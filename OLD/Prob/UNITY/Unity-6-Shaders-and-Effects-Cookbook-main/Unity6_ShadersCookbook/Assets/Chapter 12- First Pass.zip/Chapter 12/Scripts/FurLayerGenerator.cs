using UnityEngine;

[ExecuteAlways]
public class FurLayerGenerator : MonoBehaviour
{
    public Material baseMaterial; // Shared material for all layers
    public float startValue = 0.05f; // Starting FUR_MULTIPLIER value
    public float stepSize = 0.05f; // Step size for FUR_MULTIPLIER
    private int baseRenderQueue = 3000; // Default render queue for fur layers

    public bool debugMode = true; // Toggle for debug mode

    private float updateInterval = 0.1f; // Time interval for updates
    private float timeSinceLastUpdate = 0.0f; // Timer to track update intervals

    [ContextMenu("Generate Fur Layers")]
    public void GenerateFurLayers()
    {
        // Validate inputs
        if (baseMaterial == null)
        {
            Debug.LogError("Base material is not assigned!");
            return;
        }

        // Clear existing fur layers (back-to-front loop)
        for (int i = transform.childCount - 1; i >= 0; i--)
        {
            Transform child = transform.GetChild(i);
            if (child.name.Contains("FurLayer"))
            {
                DestroyImmediate(child.gameObject);
            }
        }

        // Calculate the total number of layers based on step size
        int layerCount = Mathf.CeilToInt((1 - startValue) / stepSize);

        // Generate fur layers
        for (int i = 0; i < layerCount; i++)
        {
            // Calculate FUR_MULTIPLIER
            float furMultiplier = startValue + (stepSize * i);

            if (furMultiplier > 1.0f)
            {
                break; // Stop if we exceed the maximum value
            }


            // Create a new child object for the fur layer
            GameObject layer = new GameObject($"FurLayer_{i}");
            layer.transform.SetParent(transform);
            layer.transform.localPosition = Vector3.zero;
            layer.transform.localRotation = Quaternion.identity;
            layer.transform.localScale = Vector3.one;

            // Add a MeshFilter and MeshRenderer to the layer
            MeshFilter meshFilter = layer.AddComponent<MeshFilter>();
            MeshRenderer meshRenderer = layer.AddComponent<MeshRenderer>();

            // Copy the mesh from the parent
            MeshFilter parentMeshFilter = GetComponent<MeshFilter>();
            if (parentMeshFilter != null)
            {
                meshFilter.sharedMesh = parentMeshFilter.sharedMesh;
            }

            // Assign the base material and set FUR_MULTIPLIER
            Material layerMaterial = new Material(baseMaterial);
            layerMaterial.SetFloat("_FUR_MULTIPLIER", furMultiplier);
            meshRenderer.sharedMaterial = layerMaterial;
            layerMaterial.renderQueue = baseRenderQueue + i;
        }

        Debug.Log($"Generated fur layers with FUR_MULTIPLIER from {startValue} to 1 in steps of {stepSize}.");
    }

    public void Start()
    {
        GenerateFurLayers();
    }

    private void Update()
    {
        // Ensure safe execution in edit mode
        if (debugMode && isActiveAndEnabled)
        {
            timeSinceLastUpdate += Time.deltaTime;
            if (timeSinceLastUpdate >= updateInterval)
            {
                GenerateFurLayers();
                timeSinceLastUpdate = 0.0f;
            }
        }
    }
}
